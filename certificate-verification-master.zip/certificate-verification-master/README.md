Steps included in README.md of both the frontend and backend folders
