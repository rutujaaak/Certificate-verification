Steps to install certificate verification frontend of React Typescript

cd frontend
npm install 
npm run dev 