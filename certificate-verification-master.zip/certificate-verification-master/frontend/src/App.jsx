import CertificateForm from "./CertificateForm";
import "./index.css";

function App() {
    return (
        <div className="app">
            <CertificateForm />
        </div>
    );
}

export default App;
